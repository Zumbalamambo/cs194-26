# Project 3 README

# the hybrid_image_starter.py will run all four components of part 1 after inserting in the filenames that you want to apply the methods to. All results will be saved in the corresponding image directory (1_#).

# the proj4_starter.py will run the toy example from 2.1 and will output the result into the 2_1 directory.

# The poisson_blend.py file will run the portion of project 2.2 after passing in a source image, target image, and a mask. Results will be outputted on the 2_2 directory.